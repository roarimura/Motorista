package br.com.fiap.action;

import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.persistence.EntityManager;

import br.com.fiap.dao.MotoristaDAO;
import br.com.fiap.entity.Motorista;

@ManagedBean
@SessionScoped
public class MotoristaBean {
	
	private Motorista motorista = new Motorista();
	
	private List<Motorista> listaMotorista;
	
	private long idMotorista;
	
	private Motorista motoristaSelecionado;
	
	public Motorista getMotorista() {
		return motorista;
	}

	public void setMotorista(Motorista motorista) {
		this.motorista = motorista;
	}
	
	public List<Motorista> getListaMotorista() {
		return listaMotorista;
	}

	public void setListaMotorista(List<Motorista> listaMotorista) {
		this.listaMotorista = listaMotorista;
	}
	
	public long getIdMotorista() {
		return idMotorista;
	}

	public void setIdMotorista(long idMotorista) {
		this.idMotorista = idMotorista;
	}
	
	public Motorista getMotoristaSelecionado() {
		return motoristaSelecionado;
	}

	public void setMotoristaSelecionado(Motorista motoristaSelecionado) {
		this.motoristaSelecionado = motoristaSelecionado;
	}

	public void salvar() {
		this.motorista.setCreateTime(new Date());
		
		EntityManager manager = MotoristaDAO.getEntityManager();
		manager.getTransaction().begin();
		manager.persist(motorista);
		manager.getTransaction().commit();
		manager.close();
		
		FacesMessage facesMessage = new FacesMessage("Registro salvo com sucesso!");
		FacesContext.getCurrentInstance().addMessage(null, facesMessage);
	}
	
	public void consultar() {
		EntityManager manager = MotoristaDAO.getEntityManager();
		this.listaMotorista = manager.createQuery("from Motorista").getResultList();
		manager.close();
	}
	
	public void atualizar() {
		EntityManager manager = MotoristaDAO.getEntityManager();
		manager.getTransaction().begin();
		manager.merge(motoristaSelecionado);
		manager.getTransaction().commit();
		manager.close();
		
		FacesMessage facesMessage = new FacesMessage("Registro alterado com sucesso!");
		FacesContext.getCurrentInstance().addMessage(null, facesMessage);
	}

	public void excluir() {
		System.out.println("tste");
		EntityManager manager = MotoristaDAO.getEntityManager();
		manager.getTransaction().begin();
		Object obj = manager.merge(motoristaSelecionado);
		manager.remove(obj);		
		manager.getTransaction().commit();
		manager.close();
		this.consultar();
	}
	
	public String consultarAlteracao() {
		this.consultar();
		return "consulta";
	}
	
}
