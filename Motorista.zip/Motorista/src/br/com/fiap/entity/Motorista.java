package br.com.fiap.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TB_MOTORISTA")
public class Motorista {

	@Id
	@SequenceGenerator(allocationSize=1,initialValue=1,name="SEQ_TB_MOTORISTA", sequenceName="SEQ_TB_MOTORISTA")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SEQ_TB_MOTORISTA")
	private long userId; //USER_ID
	
	@Column(name = "FIRST_NAME", length = 100)
	private String firstName; //FIRST_NAME
	
	@Column(name = "LAST_NAME", length = 100)
	private String lastName; //LAST_NAME
	
	@Column(name = "EMAIL", length = 255)
	private String email; //EMAIL
	
	@Column(name = "DATE_OF_BIRTH", length = 45)
	private String birthDate; //DATE_OF_BIRTH
	
	@Column(name = "PHONE_NUMBER", length = 20)
	private String phoneNumber; //PHONE_NUMBER
	
	@Column(name = "PHONE_VALIDATED", length = 1)
	private char phoneValidated; //PHONE_VALIDATED
	
	@Column(name = "EMAIL_CONFIRMED", length = 1)
	private char emailConfirmed; //EMAIL_CONFIRMED
		
	@Column(name = "CREATE_TIME")
	private Date createTime; //CREATE_TIME
	
	@Column(name = "PASSWORD_ENC", length = 100)
	private String passwordEcn; //PASSWORD_ENC
	
	@Column(name = "PASSWORD_SALT", length = 50)
	private String passwordSalt; //PASSWORD_SALT

	public String getFirstName() {
		return firstName;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public char getPhoneValidated() {
		return phoneValidated;
	}

	public void setPhoneValidated(char phoneValidated) {
		this.phoneValidated = phoneValidated;
	}

	public char getEmailConfirmed() {
		return emailConfirmed;
	}

	public void setEmailConfirmed(char emailConfirmed) {
		this.emailConfirmed = emailConfirmed;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getPasswordEcn() {
		return passwordEcn;
	}

	public void setPasswordEcn(String passwordEcn) {
		this.passwordEcn = passwordEcn;
	}

	public String getPasswordSalt() {
		return passwordSalt;
	}

	public void setPasswordSalt(String passwordSalt) {
		this.passwordSalt = passwordSalt;
	}
	
}
